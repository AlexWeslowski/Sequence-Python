#![allow(unused_imports)]
#![allow(unused)]

extern crate crossbeam;
extern crate flurry;
extern crate itertools;
extern crate num;
extern crate primes;
extern crate seize;
extern crate shared_memory;
extern crate std;

mod sequence;

use flurry::HashSet;
use itertools::Itertools;
use num::rational::{Ratio, Rational32, Rational64};
use primes::{PrimeSet, Sieve};
use sequence::Sequence;
use shared_memory::*;
// use std::collections::HashSet;
use std::env;
use std::thread;
use std::time::{Duration, Instant};
use std::str;
use std::sync::{Arc, Mutex, RwLock};
use std::sync::atomic::{AtomicI8, AtomicI64};


struct Main
{
    anumthreads: AtomicI64,
    t1: Instant,
    astart: AtomicI64,
    afinish: AtomicI64,
    half: Ratio<i64>
}


impl Main
{

pub fn print_duration(&mut self, icount: i64)
{
    let fcount = icount as f64;
    let fmins = (self.t1.elapsed().as_secs() as f64)/60.0;
    println!("{:.2} minutes ~ {:.2} per min", (100.0*fmins).round()/100.0, (100.0*fcount/fmins).round()/100.0);    
}

pub fn do_work(&mut self, nstart: i64, nfinish: i64, inumthreads: i64, ithread: i64, setprimes: Arc<HashSet<i64>>)
{
    let mut seq: Sequence = Sequence::new(2);
    seq.setprimes = setprimes;
    
    let thousands: i64 = 100000 + ithread;
    for n in nstart..nfinish
    {
        if n % inumthreads != ithread
        {
            continue;
        }
        for sfc in seq.factor_combinations(n)
        { 
            let scd: Ratio<i64> = seq.calc_density(&sfc);
            if scd == self.half
            {
                let vec: String = Itertools::join(&mut sfc.iter(), ", ");
                let num: String = n.to_string().as_bytes().rchunks(3).rev().map(str::from_utf8).collect::<Result<Vec<&str>, _>>().unwrap().join(",");
                println!("{}   {}", vec, num);
            }
        }
        if (n - nstart) % thousands == 0
        {
            self.print_duration(n - nstart);   
        }
    }
}
}



fn init(pow2: u32) -> HashSet<i64>
{
    let mut setprimes: HashSet<i64> = HashSet::<i64>::new();
    let two: i64 = 2;
    let twopow: i64 = two.pow(pow2);
    let mut pset = Sieve::new();
    let guard: flurry::Guard = setprimes.guard();
    for p in pset.iter()
    {
        let i64p: i64 = i64::try_from(p).ok().unwrap();
        setprimes.insert(i64p, &guard);
        if i64p > twopow
        {
            break;
        }
    }
    drop(guard);
    return setprimes;
}


/*
 * 
 * https://play.rust-lang.org/?version=stable&mode=debug&edition=2021
 * 
 */
fn main() 
{
    let args: Vec<String> = env::args().collect();
    let t1: Instant = Instant::now();
    let inumthreads: i64 = args[1].parse::<i64>().ok().unwrap();
    let anumthreads: AtomicI64 = AtomicI64::new(inumthreads);
    let istart: i64 = args[2].parse::<i64>().ok().unwrap();
    let astart: AtomicI64 = AtomicI64::new(istart);
    let ifinish: i64 = args[3].parse::<i64>().ok().unwrap();
    let afinish: AtomicI64 = AtomicI64::new(ifinish);
    let half: Ratio<i64> = Ratio::<i64>::new(1, 2);
    println!("starting with num_threads={}, istart={}, ifinish={}", inumthreads, istart, ifinish);
    
    let mut setprimes1: Arc<HashSet<i64>> = Arc::new(init(28));
    thread::scope(|scp| 
    {
        let mut threads = vec![];
        for ith in 0..(inumthreads as usize)
        {
            let setprimes2: Arc<HashSet<i64>> = setprimes1.clone();
            threads.push(scp.spawn(move || {
                let mut m = Main { t1: t1, anumthreads: AtomicI64::new(inumthreads), astart: AtomicI64::new(istart), afinish: AtomicI64::new(ifinish), half: half };
                m.do_work(istart, ifinish, inumthreads, ith as i64, setprimes2);
            }));
        }
        // 
        // https://stackoverflow.com/questions/68966949/unable-to-join-threads-from-joinhandles-stored-in-a-vector-rust
        // 
        for th in threads 
        {
            let _ = th.join();
        }
    });
}



