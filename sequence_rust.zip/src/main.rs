#![allow(unused_imports)]
#![allow(unused)]

extern crate std;
extern crate itertools;
extern crate num;
extern crate shared_memory;

mod sequence;

use std::env;
use sequence::Sequence;
use std::collections::HashSet;
use std::time::{Duration, Instant};
use num::rational::{Ratio, Rational32, Rational64};
use itertools::Itertools;
use std::str;
use shared_memory::*;



fn print_duration(istart: i64, ifinish: i64, t1: Instant)
{
    // debug = 3,461 per minute
    // release = 6,269 per minute
    let idur = (ifinish - istart) as f64;
    let mins = (t1.elapsed().as_secs() as f64)/60.0;
    println!("{:.2} minutes ~ {:.2} per min", (100.0*mins).round()/100.0, (100.0*idur/mins).round()/100.0);    
}


/*
 * 
 * https://play.rust-lang.org/?version=stable&mode=debug&edition=2021
 * 
 */
fn main() {
    let mut seq = Sequence::new(2);
    let half = Ratio::<i64>::new(1, 2);
    // println!("Hello world!");
    
    let args: Vec<String> = env::args().collect();
    // println!("args.len() is {}", args.len());
    let ithreads = args[1].parse::<usize>().ok().unwrap();
    let istart = args[2].parse::<i64>().ok().unwrap();
    let ifinish = args[3].parse::<i64>().ok().unwrap();
    println!("starting with num_threads={}, istart={}, ifinish={}", ithreads, istart, ifinish);
    
    let t1 = Instant::now();
    // println!("calc_density returns {}", seq.calc_density(&vec![3 as i64, 5 as i64, 17 as i64, 256 as i64]));
    for n in istart..(ifinish + 1)
    {
        for sfc in seq.factor_combinations(n)
        { 
             // dbg!(sfc.clone());
             let scd: Ratio<i64> = seq.calc_density(&sfc);
             // println!("{}", scd);
             if scd == half
             {
                 // let ary: String = vec.iter().map( |&id| id.to_string() + ", ").collect();
                 let vec: String = Itertools::join(&mut sfc.iter(), ",");
                 let num = n.to_string().as_bytes().rchunks(3).rev().map(str::from_utf8).collect::<Result<Vec<&str>, _>>().unwrap().join(",");
                 println!("{}   {}", vec, num);
             }
         }
         if n % 100000 == 0
         {
             print_duration(istart, ifinish, t1);   
         }
    }
    print_duration(istart, ifinish, t1);
}

